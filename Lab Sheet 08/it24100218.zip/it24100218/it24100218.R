setwd("C:\\Users\\it24100218\\Desktop\\IT24100218")
data<-read.table("Exercise - LaptopsWeights.txt",header =TRUE)
fix(data)
attach(data)

popmn <-mean(Weight.kg.)

pop_sd <- function(x){
  sqrt(sum((x - mean(x))^2) / length(x))
}
pop_sd_val <- pop_sd(Weight.kg.)

popmn
pop_sd_val


sample_means <- numeric(25)
sample_sds<-numeric(25)

for(i in 1:25){
  sample_i <- sample(Weight.kg., size=6, replace =TRUE)
  sample_means[i] <- mean(sample_i)
  sample_sds[i] <- sd(sample_i)
  
}
sample_means
sample_sds

mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

mean_of_sample_means
sd_of_sample_means